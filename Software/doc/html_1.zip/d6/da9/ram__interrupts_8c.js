var ram__interrupts_8c =
[
    [ "VECTOR_SIZE", "d6/da9/ram__interrupts_8c.html#a7c78836761fa3b5b124efea237dac70f", null ],
    [ "__attribute__", "d6/da9/ram__interrupts_8c.html#a3c14e0a22ba25cf2b127dc09238513fe", null ],
    [ "moveInterruptVectorToRam", "d6/da9/ram__interrupts_8c.html#ad5f6ba12e8d4c18286dbb6656634f283", null ]
];
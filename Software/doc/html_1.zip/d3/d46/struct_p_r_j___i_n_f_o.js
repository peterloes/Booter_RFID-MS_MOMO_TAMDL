var struct_p_r_j___i_n_f_o =
[
    [ "ID", "d3/d46/struct_p_r_j___i_n_f_o.html#a2c53bce50620212aa9c93a906658348b", null ],
    [ "Date", "d3/d46/struct_p_r_j___i_n_f_o.html#a212aa01c5e2574c38cc45879d848c761", null ],
    [ "Time", "d3/d46/struct_p_r_j___i_n_f_o.html#a4f608a79fc8da805926a007fe2b36ccf", null ],
    [ "Version", "d3/d46/struct_p_r_j___i_n_f_o.html#a0a958e3c9b42e9776bb0cf231172aa33", null ]
];
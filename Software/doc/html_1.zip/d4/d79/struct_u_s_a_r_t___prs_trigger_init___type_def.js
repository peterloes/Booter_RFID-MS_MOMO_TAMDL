var struct_u_s_a_r_t___prs_trigger_init___type_def =
[
    [ "rxTriggerEnable", "d4/d79/struct_u_s_a_r_t___prs_trigger_init___type_def.html#a5a87f6e2dc5999b931bf36f7dcbcadb0", null ],
    [ "txTriggerEnable", "d4/d79/struct_u_s_a_r_t___prs_trigger_init___type_def.html#ac727e9cb5c4165029b27e1e3c9b02584", null ],
    [ "prsTriggerChannel", "d4/d79/struct_u_s_a_r_t___prs_trigger_init___type_def.html#a28d6f614c734009ae4815f9703859ef5", null ]
];
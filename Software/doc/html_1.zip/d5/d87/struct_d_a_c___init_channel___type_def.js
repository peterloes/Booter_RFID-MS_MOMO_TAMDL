var struct_d_a_c___init_channel___type_def =
[
    [ "enable", "d5/d87/struct_d_a_c___init_channel___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "prsEnable", "d5/d87/struct_d_a_c___init_channel___type_def.html#a78606b3fad672fa22c1f11625fdc25ec", null ],
    [ "refreshEnable", "d5/d87/struct_d_a_c___init_channel___type_def.html#a4e872de9c7fef4ac6f2bfa11bb01557a", null ],
    [ "prsSel", "d5/d87/struct_d_a_c___init_channel___type_def.html#af7eb9d9a339b3fcba1954d65c93634a6", null ]
];
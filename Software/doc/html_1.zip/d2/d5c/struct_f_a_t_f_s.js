var struct_f_a_t_f_s =
[
    [ "fs_type", "d2/d5c/struct_f_a_t_f_s.html#a3630ef0b29c45ef8e0c1de639efab754", null ],
    [ "drv", "d2/d5c/struct_f_a_t_f_s.html#af46443bf86aaaff8d411814ed640e831", null ],
    [ "csize", "d2/d5c/struct_f_a_t_f_s.html#ace95d33f1aefff4c3e821cf8eac7ec3e", null ],
    [ "n_fats", "d2/d5c/struct_f_a_t_f_s.html#af18fdbb9dec86b70abc6ee2a1217ac47", null ],
    [ "wflag", "d2/d5c/struct_f_a_t_f_s.html#adb3983f8d19ef9879f30d04b076e9ff2", null ],
    [ "fsi_flag", "d2/d5c/struct_f_a_t_f_s.html#a66c4d8e68262d5542852e2aed6ce69b4", null ],
    [ "id", "d2/d5c/struct_f_a_t_f_s.html#a7b7a6396b2c82ad46c6d8b2bf141a8dd", null ],
    [ "n_rootdir", "d2/d5c/struct_f_a_t_f_s.html#a22e74fc44cd5274ba7c3b18d5e357697", null ],
    [ "last_clust", "d2/d5c/struct_f_a_t_f_s.html#a10cd8b80b3b6474bf0d6432c8fb9d2d2", null ],
    [ "free_clust", "d2/d5c/struct_f_a_t_f_s.html#a509defa217cfb2eb777ed3c74c4ef426", null ],
    [ "fsi_sector", "d2/d5c/struct_f_a_t_f_s.html#acfd3664a92fb8edf69174ddb7dbb6244", null ],
    [ "cdir", "d2/d5c/struct_f_a_t_f_s.html#a2ff1c337066d051b15eaf9cc93279347", null ],
    [ "n_fatent", "d2/d5c/struct_f_a_t_f_s.html#a388eb0fa0f3f1449a6ab88c6674e16fc", null ],
    [ "fsize", "d2/d5c/struct_f_a_t_f_s.html#af70a0afd16367837984d6205cbfca308", null ],
    [ "fatbase", "d2/d5c/struct_f_a_t_f_s.html#a74e60540a346de6eb9f0c13d6203efa1", null ],
    [ "dirbase", "d2/d5c/struct_f_a_t_f_s.html#aebfa6556d8f94e951a8b2c1eb740e9a1", null ],
    [ "database", "d2/d5c/struct_f_a_t_f_s.html#a112ba7d33529e5c9fda3b950fff01180", null ],
    [ "winsect", "d2/d5c/struct_f_a_t_f_s.html#a285dc1de6874bb5f0c41c328c9433e14", null ],
    [ "win", "d2/d5c/struct_f_a_t_f_s.html#aabf9e848c88b78e22df6e09a0626e6f5", null ]
];
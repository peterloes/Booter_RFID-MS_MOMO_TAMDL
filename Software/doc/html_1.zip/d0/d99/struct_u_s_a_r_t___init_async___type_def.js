var struct_u_s_a_r_t___init_async___type_def =
[
    [ "enable", "d0/d99/struct_u_s_a_r_t___init_async___type_def.html#ad03d6088f3621cbf1b9154b5f17f2828", null ],
    [ "refFreq", "d0/d99/struct_u_s_a_r_t___init_async___type_def.html#a3b647a722e160769390ac1967b22b318", null ],
    [ "baudrate", "d0/d99/struct_u_s_a_r_t___init_async___type_def.html#ac4f06ea26ed6bd7ae83b92d64ac10b78", null ],
    [ "oversampling", "d0/d99/struct_u_s_a_r_t___init_async___type_def.html#a047ef8ac073d473cac78c701cbf37e34", null ],
    [ "databits", "d0/d99/struct_u_s_a_r_t___init_async___type_def.html#a4b86ff44cd07bc787d26cef503c07d51", null ],
    [ "parity", "d0/d99/struct_u_s_a_r_t___init_async___type_def.html#a7afa5d62418ae14e43e6f6776a0d9d56", null ],
    [ "stopbits", "d0/d99/struct_u_s_a_r_t___init_async___type_def.html#af587660157cea1b7e2d1b09baa5c6ca4", null ]
];
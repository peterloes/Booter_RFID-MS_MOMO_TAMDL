var searchData=
[
  ['init_5fbuf',['INIT_BUF',['../db/d89/ff_8c.html#a966fe5792671b39db1ccf655a8c1af8d',1,'ff.c']]],
  ['io_5fbit',['IO_Bit',['../db/d16/config_8h.html#aa04799bbe99b88d70a1d1d846c8329ae',1,'config.h']]],
  ['io_5fbit_5faddr',['IO_BIT_ADDR',['../db/d16/config_8h.html#adabcfca2cb7bd9dd0b891465b9afb3c5',1,'config.h']]],
  ['is_5fdisk_5fpresent',['IS_DISK_PRESENT',['../d4/d6f/microsd_8c.html#a02c7058f6a61370f7338eaae03c1942f',1,'microsd.c']]],
  ['isdbcs1',['IsDBCS1',['../db/d89/ff_8c.html#a58d63a832a117f179e41c7373d013dd6',1,'ff.c']]],
  ['isdbcs2',['IsDBCS2',['../db/d89/ff_8c.html#a66a3fa880af6078ef181656c1d7d8ef1',1,'ff.c']]],
  ['isdigit',['IsDigit',['../db/d89/ff_8c.html#a65dee564f69f2ec27f25b67a348018b9',1,'ff.c']]],
  ['islower',['IsLower',['../db/d89/ff_8c.html#a4a9d454724926bd51a3aed589a97f08b',1,'ff.c']]],
  ['isupper',['IsUpper',['../db/d89/ff_8c.html#a89b2514198590e139dd064c5d534f302',1,'ff.c']]]
];

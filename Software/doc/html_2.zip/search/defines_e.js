var searchData=
[
  ['set_5fmicrosd_5fpwr_5fpin',['SET_MICROSD_PWR_PIN',['../d4/d6f/microsd_8c.html#a909793a0a34079e30a5ae58f0ab714a9',1,'microsd.c']]],
  ['sprintf',['sprintf',['../db/d16/config_8h.html#a5998f60c4f4af322b36debdbd11d7917',1,'config.h']]],
  ['sram_5fbit_5faddr',['SRAM_BIT_ADDR',['../db/d16/config_8h.html#a56be8be00098c8ab78df37519208f3f3',1,'config.h']]],
  ['ss',['SS',['../db/d89/ff_8c.html#a42b5140fc5e09a53c8f4cba66dc0e6c1',1,'ff.c']]],
  ['st_5fclust',['ST_CLUST',['../db/d89/ff_8c.html#a08174fa72222a48a5c9e5de70c341af7',1,'ff.c']]],
  ['st_5fdword',['ST_DWORD',['../da/db9/ff_8h.html#abf5aba973d95ac5843b80aa7379cdd66',1,'ff.h']]],
  ['st_5fword',['ST_WORD',['../da/db9/ff_8h.html#a95ceb4c25b216e71baa7102939edfd0d',1,'ff.h']]],
  ['sta_5fnodisk',['STA_NODISK',['../d3/d5d/diskio_8h.html#aec625080763d6cf487e550a6c9a2dd19',1,'diskio.h']]],
  ['sta_5fnoinit',['STA_NOINIT',['../d3/d5d/diskio_8h.html#abd6503c70d862b979a3f7080a59e9acd',1,'diskio.h']]],
  ['sta_5fprotect',['STA_PROTECT',['../d3/d5d/diskio_8h.html#a9ec6dc5f6620a33fabe388d3a111ca8c',1,'diskio.h']]],
  ['sz_5fdir',['SZ_DIR',['../db/d89/ff_8c.html#ab10c2f2271dbdc132f9a6b9313fc7324',1,'ff.c']]],
  ['sz_5fpte',['SZ_PTE',['../db/d89/ff_8c.html#af133060c47366e7e557d4085d931183f',1,'ff.c']]]
];

var searchData=
[
  ['svcall_5firqn',['SVCall_IRQn',['../d9/d34/group___e_f_m32_g230_f128.html#gga666eb0caeb12ec0e281415592ae89083a4ce820b3cc6cf3a796b41aadc0cf1237',1,'efm32g230f128.h']]],
  ['systick_5firqn',['SysTick_IRQn',['../d9/d34/group___e_f_m32_g230_f128.html#gga666eb0caeb12ec0e281415592ae89083a6dbff8f8543325f3474cbae2446776e7',1,'efm32g230f128.h']]]
];

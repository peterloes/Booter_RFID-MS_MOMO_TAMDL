var searchData=
[
  ['use_5fext_5f32mhz_5fclock',['USE_EXT_32MHZ_CLOCK',['../db/d16/config_8h.html#addbfd2969e740925e800e882c5466df7',1,'config.h']]]
];

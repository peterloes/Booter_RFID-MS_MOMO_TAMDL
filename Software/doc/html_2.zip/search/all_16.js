var searchData=
[
  ['xfersprmsec',['xfersPrMsec',['../d4/d6f/microsd_8c.html#a5ea21c1043274ac135a3b0a70995e362',1,'microsd.c']]]
];

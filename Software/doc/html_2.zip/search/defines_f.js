var searchData=
[
  ['tamdl_5fmicrosd_5fpwr_5fgpio_5fport',['TAMDL_MICROSD_PWR_GPIO_PORT',['../d3/d20/microsd_8h.html#ad8ffceab13c3e2385365a238e047abbb',1,'microsd.h']]],
  ['tamdl_5fmicrosd_5fpwr_5fpin',['TAMDL_MICROSD_PWR_PIN',['../d3/d20/microsd_8h.html#aa20e0838cc454932d6ebef6a02ea517c',1,'microsd.h']]],
  ['tx_5ffifo_5fsize',['TX_FIFO_SIZE',['../d6/d24/_l_e_u_a_r_t_8c.html#a88540454f43c07e91701dd077089dcfe',1,'LEUART.c']]]
];

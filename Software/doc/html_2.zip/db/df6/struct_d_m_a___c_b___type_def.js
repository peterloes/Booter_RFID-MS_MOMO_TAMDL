var struct_d_m_a___c_b___type_def =
[
    [ "cbFunc", "db/df6/struct_d_m_a___c_b___type_def.html#af0c84d3caa964b4dc828bad31bf6d39b", null ],
    [ "userPtr", "db/df6/struct_d_m_a___c_b___type_def.html#ab734e34011f54d128fdddc1f5869956a", null ],
    [ "primary", "db/df6/struct_d_m_a___c_b___type_def.html#a10bfcb9e6056ed7543f3f606cd6e1d79", null ]
];
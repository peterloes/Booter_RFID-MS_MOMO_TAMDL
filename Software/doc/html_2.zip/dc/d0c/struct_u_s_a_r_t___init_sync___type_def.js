var struct_u_s_a_r_t___init_sync___type_def =
[
    [ "enable", "dc/d0c/struct_u_s_a_r_t___init_sync___type_def.html#ad03d6088f3621cbf1b9154b5f17f2828", null ],
    [ "refFreq", "dc/d0c/struct_u_s_a_r_t___init_sync___type_def.html#a3b647a722e160769390ac1967b22b318", null ],
    [ "baudrate", "dc/d0c/struct_u_s_a_r_t___init_sync___type_def.html#ac4f06ea26ed6bd7ae83b92d64ac10b78", null ],
    [ "databits", "dc/d0c/struct_u_s_a_r_t___init_sync___type_def.html#a4b86ff44cd07bc787d26cef503c07d51", null ],
    [ "master", "dc/d0c/struct_u_s_a_r_t___init_sync___type_def.html#a076a973bb9631a8e8a5fe1452f01f0bc", null ],
    [ "msbf", "dc/d0c/struct_u_s_a_r_t___init_sync___type_def.html#a9218e4d875c4914edc03acffe02997ac", null ],
    [ "clockMode", "dc/d0c/struct_u_s_a_r_t___init_sync___type_def.html#a1c18f48990a3bedb40fa8ec21c98a4a1", null ]
];